class Contato:
    def __init__ (self, nome, telefone, endereco):
        self.nome = nome
        self.telefone = telefone
        self.endereco = endereco
    
    '''def exclui_ctt(escolha_exclusao):
        from Exercício_016_Classes import lista_contatos
        lista_contatos.pop(escolha_exclusao - 1)
        '''