'''
1. Algoritmo para ligar um carro (Imprimir a sequência para ligar um carro)
'''
print('1. Desativar o alarme do carro')
print('2. Abrir a porta do motorista')
print('3. Entrar e sentar no banco de motorista')
print('4. Coloca a chave no miolo de ignição')
print('5. Segurar embragem')
print('6. Verificar cambio ponto morto')