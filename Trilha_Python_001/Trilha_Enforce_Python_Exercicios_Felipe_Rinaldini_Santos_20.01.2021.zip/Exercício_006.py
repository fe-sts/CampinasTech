'''
6. Algoritmo para criar uma lista usando range com 100 elementos e imprimi-la
'''
lista = []
for cont in range(0, 100):
    lista.append(cont)
print(lista)