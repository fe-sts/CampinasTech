'''
3. Algoritmo para trocar o pneu do carro (Imprimir a sequência para trocar o pneu do carro)
'''

print('1. Identificar qual pneu deve ser trocado')
print('2. Retirar do carro o estepe')
print('3. Pegar o kit com estepe, macaco e chave de roda')
print('4. Posicinar o triângulo e macaco')
print('5. Afrouxar os parafusos')
print('5. Elevar o Carro')
print('6. Terminar de retirar os parafusos')
print('7. Retirar a roda')
print('8. Inserir o estepe e começar a parafusar')
print('9. Baixar o carro')
print('10. Terminar de apertar os parafusos')