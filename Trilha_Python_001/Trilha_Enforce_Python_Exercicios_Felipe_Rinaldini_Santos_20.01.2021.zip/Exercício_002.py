'''
2. Algoritmo para ir ao banco para sacar dinheiro (Imprimir a sequência para ir ao banco e sacar dinheiro)
'''
print('1. Pensar no trajeto')
print('2. Definir qual meio de locomoção (veículo/a pé)')
print('3. Iniciar o trajeto')
print('4. Chegando ao banco, abria porta e entrar')
print('5. Se dirigir ao caixa eletrônico')
print('6. Acessar sua conta (inserir cartão e senha)')
print('7. Escolher a opção de saque e valor')
print('8. Escolher o valor e confirmar')
print('9. Retirar o dinheiro e guardá-lo')